package coll.app.boiler.dto.response.userinfo;

public record  UserInfoDto(
         String title,
         Boolean completed
) {
}
