package coll.app.boiler.controller.impl;

import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/api/accounts")
public interface AccountApiVersion {
}
