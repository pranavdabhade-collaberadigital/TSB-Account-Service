package coll.app.boiler.controller.impl;

import coll.app.boiler.dto.response.accounts.AccountDTO;
import coll.app.boiler.service.AccountsService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import reactor.core.publisher.Mono;

public class AccountsController implements AccountApiVersion {

    private final AccountsService accountsService;

    AccountsController(AccountsService accountsService) {
        this.accountsService = accountsService;
    }

    @GetMapping("/accounts")
    public Mono<AccountDTO> getAccounts(
            @RequestParam("accounts")
            String accounts)
    {
        return accountsService.getAccounts(accounts);
    }

}
