package coll.app.boiler.service.impl;

import coll.app.boiler.dto.response.accounts.AccountDTO;
import coll.app.boiler.service.AccountsService;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
@Service
public class AccountsServiceImpl implements AccountsService {

    private final WebClient webClient;




        public AccountsServiceImpl(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.baseUrl("http://localhost:8080/accounts").build();
    }
    @Override
    public Mono<AccountDTO> getAccounts(String accountDetails) {
        return webClient.get()
                .uri("/accounts")
                .retrieve()
                .bodyToMono(AccountDTO.class);


    }
}
