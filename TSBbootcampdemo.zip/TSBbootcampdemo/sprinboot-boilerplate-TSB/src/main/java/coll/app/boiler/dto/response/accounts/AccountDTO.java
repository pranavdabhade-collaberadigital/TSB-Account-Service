package coll.app.boiler.dto.response.accounts;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;

@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value = JsonInclude.Include.NON_EMPTY,content = JsonInclude.Include.NON_NULL)
public record AccountDTO(
        String accountId,
        String status,
        String statusUpdateDateTime,
        String currency,
        String accountType,
        String accountSubType,
        String nickname,
        String openingDate,
        AccountDetailsDTO accountDetails
        ) {}
