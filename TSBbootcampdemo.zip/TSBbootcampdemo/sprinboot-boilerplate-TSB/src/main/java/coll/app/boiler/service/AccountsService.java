package coll.app.boiler.service;

import coll.app.boiler.dto.response.accounts.AccountDTO;
import reactor.core.publisher.Mono;

public interface AccountsService {
    Mono<AccountDTO> getAccounts(String accountDetails);
}
