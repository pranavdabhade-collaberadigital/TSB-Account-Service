package coll.app.boiler;

import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class BoilerApplicationTests {

}
